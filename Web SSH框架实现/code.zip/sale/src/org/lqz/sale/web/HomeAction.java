package org.lqz.sale.web;

public class HomeAction extends BaseAction {

	private String moduleName;

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String toTitle() throws Exception {
		// TODO Auto-generated method stub
		return "toTitle";
	}

	public String toLeft() throws Exception {
		// TODO Auto-generated method stub
		return "toLeft";
	}

	public String toMain() throws Exception {
		// TODO Auto-generated method stub
		return "toMain";
	}
}
