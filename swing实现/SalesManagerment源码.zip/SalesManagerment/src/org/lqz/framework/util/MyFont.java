package org.lqz.framework.util;

/**
 * 自定义字体工具类
 */
import java.awt.Font;

public class MyFont {
	public static Font Static = new Font("微软雅黑", Font.PLAIN, 14);
}
